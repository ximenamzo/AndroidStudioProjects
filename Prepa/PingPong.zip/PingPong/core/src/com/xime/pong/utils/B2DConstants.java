package com.xime.pong.utils;

public class B2DConstants {

    private B2DConstants() {}

    public static float PPM = 32f;
}
